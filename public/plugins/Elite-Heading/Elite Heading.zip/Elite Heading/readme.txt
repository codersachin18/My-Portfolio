Elite Heading - Elementor widget with 5 gradients and typing animations.
