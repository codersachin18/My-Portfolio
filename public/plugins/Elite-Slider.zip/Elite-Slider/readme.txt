=== Elite Slider ===
Author: Coder Sachin
Tags: slider, responsive, shortcode, images
Requires at least: 6.0
Tested up to: 6.8
Stable tag: 1.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html


== Description ==
Elite Slider lets you create responsive sliders easily with a shortcode. Add unlimited sliders with images, titles, and custom settings.

== Installation ==
1. Install The Plugin
2. Activate it via the Plugins menu
3. In left Side Click On Elite Slider Tab
4. Click On Add Slider
5. Add Title- Images,autoplay,etc 
6. Click On Publish And Copy Shortcode 
7. Add Shortcode Widget In Page And Past Copied Shortcode .
8. Publish The Page And See preview

== Screenshots ==
1. Dashboard slider list
2. Add/Edit slider page
3. Frontend preview
4. Settings panel

== Frequently Asked Questions ==
= Can I have multiple sliders? =
Yes, each slider has its own shortcode.

= Can I adjust slider height? =
Yes, in the settings panel.

== Changelog ==
= 1.0 =
* Initial release

== Upgrade Notice ==
= 1.0 =
First release
